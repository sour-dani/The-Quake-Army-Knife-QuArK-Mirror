object MainForm: TMainForm
  Left = 394
  Top = 210
  Width = 604
  Height = 511
  HorzScrollBar.Color = clYellow
  HorzScrollBar.ParentColor = False
  HorzScrollBar.Range = 1000
  HorzScrollBar.Style = ssFlat
  VertScrollBar.Color = clYellow
  VertScrollBar.ParentColor = False
  VertScrollBar.Range = 1000
  VertScrollBar.Smooth = True
  VertScrollBar.Style = ssFlat
  AutoScroll = False
  Caption = 'CheckWin32Version patch demo'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  PixelsPerInch = 96
  TextHeight = 13
  object Memo1: TMemo
    Left = 0
    Top = 0
    Width = 1000
    Height = 1000
    Align = alClient
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -12
    Font.Name = 'Courier New'
    Font.Style = []
    Lines.Strings = (
      'Description:'
      
        'CheckWin32Version routine returns incorrect result for MinorVers' +
        'ion.'
      ''
      
        'This affects flat scrollbar VCL support in Delphi 6 Update Pack ' +
        '#2 because'
      
        'TScrollingWinControl.CreateWnd does a check for Windows XP to di' +
        'sable the support.'
      
        'Due the bug the flat scrollbar support is disabled for Windows 2' +
        '000 as well.')
    ParentColor = True
    ParentFont = False
    ReadOnly = True
    TabOrder = 0
  end
end
