program PatchDemo;

uses
  Forms,
  PatchDemoMain in 'PatchDemoMain.pas' {MainForm},
  D6CheckWin32VersionFix in 'D6CheckWin32VersionFix.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TMainForm, MainForm);
  Application.Run;
end.
